﻿namespace CordovaReyes.Models
{
    public class Genero
    {
        public int id { get; set; }
        public String nombre { get; set; }
        public Boolean estado { get; set; }
    }
}
