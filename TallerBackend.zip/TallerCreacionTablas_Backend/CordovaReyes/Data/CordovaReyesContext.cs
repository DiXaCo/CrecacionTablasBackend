﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using CordovaReyes.Models;

namespace CordovaReyes.Data
{
    public class CordovaReyesContext : DbContext
    {
        public CordovaReyesContext (DbContextOptions<CordovaReyesContext> options)
            : base(options)
        {
        }

        public DbSet<CordovaReyes.Models.Genero> Genero { get; set; } = default!;
    }
}
